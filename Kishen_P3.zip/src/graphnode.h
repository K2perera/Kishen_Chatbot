#ifndef GRAPHNODE_H_
#define GRAPHNODE_H_

#include <vector>
#include <string>
#include "chatbot.h"
#include <memory>

// forward declarations
class GraphEdge;

class GraphNode
{
private:
   //T4
    std::vector<std::unique_ptr<GraphEdge>> childEdges;  
    std::vector<GraphEdge *> parentEdges; 
    ChatBot _chatBot;
    int ID;
    std::vector<std::string> answers;

public:
    // constr and destr 
    GraphNode(int id);
    ~GraphNode();

    // getter / setter
    int GetID() { 
    	return ID; 
    }
    int GetNumberOfParents() { 
    	return parentEdges.size(); 
    } 
    int GetNumberOfChildEdges() { 
    	return childEdges.size(); 
   	}
    GraphEdge *GetChildEdgeAtIndex(int index);
    std::vector<std::string> GetAnswers() { 
    	return answers; 
  	}
    void MoveChatbotToNewNode(GraphNode *newNode); 
    void MoveChatbotHere(ChatBot chatbot);
    void AddToken(std::string token); 
    void AddEdgeToParentNode(GraphEdge *edge);
    void AddEdgeToChildNode(std::unique_ptr<GraphEdge> edge); //T4

};

#endif