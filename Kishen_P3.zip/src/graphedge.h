#ifndef GRAPHEDGE_H_
#define GRAPHEDGE_H_

#include <vector>
#include <string>

class GraphNode; // forward declaration

class GraphEdge
{
private:
    // data handles (not owned)
    GraphNode *_childNode;
    GraphNode *_parentNode;

    // proprietary members
    int _id;
    std::vector<std::string> _keywords; // list of topics associated with this edge
    

public:
    // constr and destr
    GraphEdge(int id);

    // getter / setter 
    void SetParentNode(GraphNode *parentNode);
    GraphNode *GetChildNode() { 
    	return _childNode; 
    }
    int GetID() { 
    	return _id; 
    }
    void SetChildNode(GraphNode *childNode);
    std::vector<std::string> GetKeywords() { 
    	return _keywords;  
    }
    void AddToken(std::string token);
};

#endif 