#ifndef CHATLOGIC_H_
#define CHATLOGIC_H_

#include <vector>
#include <string>
#include "chatgui.h"

// forward declarations
class ChatBot;
class GraphEdge;
class GraphNode;

class ChatLogic
{
private:
   
    std::vector<std::unique_ptr<GraphNode>> _nodes; //task 3
    std::vector<GraphEdge *> _edges;
    GraphNode *_currentNode;
    ChatBot *CB;
    ChatBotPanelDialog *PD;

    // proprietary type definitions
    typedef std::vector<std::pair<std::string, std::string>> tokenlist;
    template <typename T>
    void AddAllTokensToElement(std::string tokenID, tokenlist &tokens, T &element);

public:
    // constr and destr
    ChatLogic();
    ~ChatLogic();

    void SetPanelDialogHandle(ChatBotPanelDialog *panelDialog);
    void SetChatbotHandle(ChatBot *chatbot);
    wxBitmap *GetImageFromChatbot(); 
    void LoadAnswerGraphFromFile(std::string filename);
    void SendMessageToChatbot(std::string message);
    void SendMessageToUser(std::string message);
};

#endif 