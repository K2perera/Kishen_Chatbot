#include "graphedge.h"
#include "graphnode.h"

GraphNode::GraphNode(int id)
{
    ID = id;
}

GraphNode::~GraphNode()
{

}

void GraphNode::AddToken(std::string token)
{
    answers.push_back(token);
}

void GraphNode::AddEdgeToParentNode(GraphEdge *edge)
{
    parentEdges.push_back(edge);
}

void GraphNode::AddEdgeToChildNode(std::unique_ptr<GraphEdge> edge)
{
    childEdges.push_back(std::move(edge)); // T4
}

void GraphNode::MoveChatbotHere(ChatBot chatbot) //T5
{
    _chatBot = std::move(chatbot);
    _chatBot.SetCurrentNode(this);
}

void GraphNode::MoveChatbotToNewNode(GraphNode *newNode)
{
    newNode->MoveChatbotHere(std::move(_chatBot)); //T5
}

GraphEdge *GraphNode::GetChildEdgeAtIndex(int index)
{
    return childEdges[index].get(); //T4 
}