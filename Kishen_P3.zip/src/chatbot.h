#ifndef CHATBOT_H_
#define CHATBOT_H_

#include <wx/bitmap.h>
#include <string>

class GraphNode; // forward declaration
class ChatLogic; // forward declaration

class ChatBot
{
private:
    // data handles (owned)
    wxBitmap *AI;
    GraphNode *CNode; 
    ChatLogic *CL; //chat logic  
    GraphNode *RN;

    // proprietary functions
    int ComputeLevenshteinDistance(std::string s1, std::string s2);

public:
    ChatBot();                     
    ChatBot(std::string filename); 
    ~ChatBot();
    ChatBot(const ChatBot &other);            //Copy Constructor 
    ChatBot(ChatBot &&other);                 //Move Constructor
    ChatBot& operator=(const ChatBot &other); //Copy Assingment
    ChatBot& operator=(ChatBot &&other);      //Move Assignment
    void SetCurrentNode(GraphNode *node);
    void SetRootNode(GraphNode *rootNode) { 
    	RN = rootNode; 
    }
    void SetChatLogicHandle(ChatLogic *chatLogic) { 
    	CL = chatLogic; 
    }
    wxBitmap *GetImageHandle() { 
    	return  AI; 
    }
    void ReceiveMessageFromUser(std::string message);
};

#endif 